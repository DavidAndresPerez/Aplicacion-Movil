package com.example.proyecto.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.proyecto.conexion.ConexionSQLite;
import com.example.proyecto.pojo.Usuario;

public class UsuarioDAO {

    //Variables
    private SQLiteDatabase dbHelper;

    //Constructor
    public UsuarioDAO(Context context) {
        dbHelper = new ConexionSQLite(context).getWritableDatabase();
    }

    public UsuarioDAO(SQLiteDatabase dbHelper) {
        this.dbHelper = dbHelper;
    }


    //Metodo para inserta un Usuario en la base de datos
    public long insertarUsuario(Usuario usuario) {

        ContentValues values = new ContentValues();
        values.put("nombre", usuario.getNombre());
        values.put("contrasenia", usuario.getContrasenia());
        values.put("email", usuario.getEmail());


        return dbHelper.insert("USUARIOS", null, values);

    }

    //Metodo para buscar un usuario en la base de datos
    public Usuario buscarUsuario(String nombre, String contrasenia) {

        Usuario usuario = null;

        //Consulta para buscar al usuario
        String query = "SELECT * FROM USUARIOS WHERE nombre = ? AND contrasenia = ?";

        //Cursor
        Cursor cursor = dbHelper.rawQuery(query, new String[]{nombre, contrasenia});

        //Si encuentra el usuario
        if (cursor.moveToFirst()) {
            usuario = new Usuario();
            usuario.setId(cursor.getInt(0));
            usuario.setNombre(cursor.getString(1));
            usuario.setContrasenia(cursor.getString(2));
            usuario.setEmail(cursor.getString(3));
        }

        cursor.close();
        return usuario;
    }

    //Metodo para buscar un usuario por su nombre para el registro
    public boolean buscarUsuario(String nombre) {

        boolean existe = false;

        //Consulta para buscar al usuario
        String query = "SELECT * FROM USUARIOS WHERE nombre = ?";

        //Cursor
        Cursor cursor = dbHelper.rawQuery(query, new String[]{nombre});

        if (cursor.moveToFirst()) {
            existe = true;
        }

        cursor.close();
        return existe;
    }
}
