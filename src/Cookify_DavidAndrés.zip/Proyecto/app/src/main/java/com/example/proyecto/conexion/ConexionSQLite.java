package com.example.proyecto.conexion;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.proyecto.pojo.Usuario;
import com.example.proyecto.dao.UsuarioDAO;

public class ConexionSQLite extends SQLiteOpenHelper {

    //Variables
    private static final String DATABASE_NAME = "cookify.db";
    private static final int DATABASE_VERSION = 5;
    private Context context;

    //Constructor
    public ConexionSQLite(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;

    }

    //Crear las tablas

    //Usuarios
    public static final String CREAR_TABLA_USUARIOS =
            "CREATE TABLE IF NOT EXISTS USUARIOS (" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "nombre TEXT NOT NULL UNIQUE, " +
            "contrasenia TEXT NOT NULL," +
            "email TEXT)";

    //Imagenes
    public static final String CREAR_TABLA_IMAGENES =
            "CREATE TABLE IF NOT EXISTS IMAGENES (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "imagen BLOB NOT NULL)";

    //Recetas
    public static final String CREAR_TABLA_RECETAS =
            "CREATE TABLE IF NOT EXISTS RECETAS (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "nombre TEXT NOT NULL," +
                    "ingredientes TEXT," +
                    "elaboracion TEXT," +
                    "favorita INTEGER DEFAULT 0," + // 0 false 1 true
                    "usuario_id INTEGER," +
                    "id_imagen INTEGER," +
                    "FOREIGN KEY(usuario_id) REFERENCES USUARIOS(id)," +
                    "FOREIGN KEY(id_imagen) REFERENCES IMAGENES(id))";



    //Metodo para insertar usuarios iniciales
    private void insertarUsuariosIniciales(SQLiteDatabase db) {
        UsuarioDAO usuarioDAO = new UsuarioDAO(db);
        Usuario admin = new Usuario();
        admin.setNombre("admin");
        admin.setContrasenia("1234");
        admin.setEmail("admin@recetas.com");
        usuarioDAO.insertarUsuario(admin);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Crear las tablas
        db.execSQL(CREAR_TABLA_USUARIOS);
        db.execSQL(CREAR_TABLA_IMAGENES);
        db.execSQL(CREAR_TABLA_RECETAS);

        //Insertar usuario inicial
        insertarUsuariosIniciales(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //Borrar y volver a crearla
        db.execSQL("DROP TABLE IF EXISTS RECETAS");
        db.execSQL("DROP TABLE IF EXISTS IMAGENES");
        db.execSQL("DROP TABLE IF EXISTS USUARIOS");
        onCreate(db);
    }
}
