package com.example.proyecto.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyecto.R;
import com.example.proyecto.dao.UsuarioDAO;
import com.example.proyecto.pojo.Usuario;

public class Login extends AppCompatActivity {


    //Variables
    TextView usuario, contrasenia, registrarse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        usuario = findViewById(R.id.tv_Usuario);
        contrasenia = findViewById(R.id.tv_Contasenia);
        registrarse = findViewById(R.id.tv_Registrarse);

        //Solicitar permiso de notificaciones
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (androidx.core.content.ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {

                androidx.core.app.ActivityCompat.requestPermissions(this,
                        new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
    }

    //Metodo para iniciar sesion
    public void inicioSesion(View v){
        String usu = usuario.getText().toString().trim();
        String contra = contrasenia.getText().toString().trim();

        //Comprobar que no estan vacios
        if (usu.isEmpty() || contra.isEmpty()){
            Toast.makeText(this, "Rellena todos los campos", Toast.LENGTH_SHORT).show();
        } else {

            //Comprobar que el usuario y la contraseña son correctos
            UsuarioDAO usuarioDAO = new UsuarioDAO(this);
            Usuario usuario = usuarioDAO.buscarUsuario(usu, contra);

            if (usuario != null) {
                Toast.makeText(this, "Bienvenido de nuevo " + usuario.getNombre(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Login.this, MainActivity.class);
                i.putExtra("ID_USUARIO", usuario.getId());
                startActivity(i);
                finish();
            } else {
                Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
            }
        }

    }

    //Metodo para ir al registro
    public void registro(View v){
        Intent i = new Intent(Login.this, Registro.class);
        startActivity(i);
    }
}