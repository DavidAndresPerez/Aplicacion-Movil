package com.example.proyecto.ui;

import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyecto.R;
import com.example.proyecto.dao.UsuarioDAO;
import com.example.proyecto.pojo.Usuario;

import java.util.Calendar;

public class Registro extends AppCompatActivity {

    //Varibles
    Spinner prefijos;
    TextView usuario, email,telefono, contrasenia;
    CheckBox condiciones;
    Button registrarse;

    int anio,mes,dia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registro);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Referencias las variables
        prefijos = findViewById(R.id.sp_Prefijos);
        usuario = findViewById(R.id.tv_Usuario);
        email = findViewById(R.id.tv_Email);
        contrasenia = findViewById(R.id.tv_Constrasenia);
        telefono = findViewById(R.id.tv_Telefono);
        condiciones = findViewById(R.id.ck_Terminos);
        registrarse = findViewById(R.id.btn_CrearCuenta);

        //Array para los prefijos del numero de telefono
        String[] prefijosArray = {"+34", "+1", "+44", "+49"};

        // Configurar Spinner usando el array directamente
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                R.layout.seleccion_prefijo,
                prefijosArray
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        prefijos.setAdapter(adapter);

       prefijos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
           @Override
           public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
               String selectedPrefijo = prefijosArray[position];

           }

           @Override
           public void onNothingSelected(AdapterView<?> parent) {
                prefijos.setSelection(0);

           }
       });

        //Onclick para el boton registrarse
        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registrarse(v);
            }
        });

    }

    //Metodo para lanzar la notificacion
    public void lanzarNotificación() {
        String canal_ID = "canala_cookify";

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        //Crear el NotificationChanel
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel canal = new NotificationChannel(canal_ID, "Registro", NotificationManager.IMPORTANCE_DEFAULT);
            notificationManager.createNotificationChannel(canal);
        }

        //Actividad Destino de la notificacion
        Intent intent = new Intent(this, Login.class);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);


        //Crear la notificacion
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, canal_ID)
                .setSmallIcon(R.drawable.logo)
                .setContentTitle("¡Bienvenido/a, " + usuario.getText().toString() + "!")
                .setContentText("Registro realizado correctamente")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent) // Al pulsar, va al Login
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);

        //Mostrar la notificacion
        notificationManager.notify(1, builder.build());
    }

    //Metodo para registrarse
    public void registrarse(View view) {
        //Recoger los datos
        String nombreUsuario = usuario.getText().toString().trim();
        String emai = email.getText().toString().trim();
        String contra = contrasenia.getText().toString().trim();
        String movil = telefono.getText().toString().trim();
        boolean aceptadas = condiciones.isChecked();

        //Validaciones
        if (nombreUsuario.isEmpty() || emai.isEmpty() || contra.isEmpty() || movil.isEmpty()) {
            Toast.makeText(this, "Rellena todos los campos de texto", Toast.LENGTH_SHORT).show();
        } else if (!aceptadas) {
            Toast.makeText(this, "Debes aceptar los terminos para continuar", Toast.LENGTH_SHORT).show();
        } else if(!android.util.Patterns.EMAIL_ADDRESS.matcher(emai).matches()){
            Toast.makeText(this, "El email no es valido", Toast.LENGTH_SHORT).show();
        }else if (contra.length() < 6) {
            Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show();
        } else {
            UsuarioDAO usuarioDAO = new UsuarioDAO(this);

            if (usuarioDAO.buscarUsuario(nombreUsuario)) {
                Toast.makeText(this, "El usuario ya existe", Toast.LENGTH_SHORT).show();
            } else {

                Usuario usuario = new Usuario();
                usuario.setNombre(nombreUsuario);
                usuario.setEmail(emai);
                usuario.setContrasenia(contra);

                //Insertarlo en la base de datos
                long id = usuarioDAO.insertarUsuario(usuario);

                if (id > 0) {
                    lanzarNotificación();
                    Intent i = new Intent(Registro.this, Login.class);
                    startActivity(i);
                    finish();
                } else {
                    Toast.makeText(this, "Error al registrar el usuario", Toast.LENGTH_SHORT).show();
                }

            }
        }
    }

    public static class SplashScreen extends AppCompatActivity {

        //Variable para la progresbar
        ProgressBar progresBar;
        int tiempo = 3000;  //3 segundos de duracion
        int progresoMaximo = 100;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            EdgeToEdge.enable(this);
            setContentView(R.layout.activity_splash_screen);
            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });

            progresBar = findViewById(R.id.pbProgressBar);

            int intervalo = 60; //cada 60 ms se llena un cacho de la progresbar
            int aumento = progresoMaximo / (tiempo / intervalo);
            Handler handler = new Handler();

            Runnable runnable = new Runnable() {
                int progresoActual = 0;

                @Override
                public void run() {
                    progresoActual += aumento;
                    if (progresoActual > progresoMaximo)
                        progresoActual = progresoMaximo;

                    progresBar.setProgress(progresoActual);

                    //Aumentar el progreso hasta que llegue al 100
                    if (progresoActual < progresoMaximo) {
                        handler.postDelayed(this, intervalo);
                    } else {
                        Intent i = new Intent(SplashScreen.this, Login.class);
                        startActivity(i);
                        finish();
                    }
                }
            };
            handler.post(runnable);
        }
    }
}


