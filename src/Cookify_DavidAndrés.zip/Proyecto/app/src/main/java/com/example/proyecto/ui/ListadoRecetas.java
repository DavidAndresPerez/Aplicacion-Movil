package com.example.proyecto.ui;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ListView;
import android.widget.Toast;
import android.os.Handler;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyecto.R;
import com.example.proyecto.adapter.Adaptador_Receta;
import com.example.proyecto.dao.ImagenDAO;
import com.example.proyecto.dao.RecetaDAO;
import com.example.proyecto.pojo.Receta;

import java.util.ArrayList;

public class ListadoRecetas extends AppCompatActivity {

    //Variables
    AutoCompleteTextView buscador;
    ListView lista;

    //Variables para la base de datos
    RecetaDAO recetaDAO;
    ImagenDAO imagenDAO;
    ArrayList<Receta> listaRecetas;
    Adaptador_Receta adapter;

    //Variables para el hilo del buscador
    private Handler handler = new Handler();
    private Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_listado_recetas);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Referenciar las variables
        buscador = findViewById(R.id.atv_buscarReceta);
        lista = findViewById(R.id.lv_recetas);

        //ID del usuario
        int idUsuario = getIntent().getIntExtra("ID_USUARIO", -1);

        //Inicializar los DAOS
        recetaDAO = new RecetaDAO(this);
        imagenDAO = new ImagenDAO(this);

        //Recoger las recetas de este usuario de la base de datos
        listaRecetas = (ArrayList<Receta>) recetaDAO.obtenerRecetas(idUsuario);

        //Asociar las recetas al adaptador y mostrar
        adapter = new Adaptador_Receta(this, listaRecetas, imagenDAO, idUsuario);
        lista.setAdapter(adapter);

        //Pasar a la ventana de receta especifica
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Receta r = (Receta) adapter.getItem(position);

                Intent i = new Intent(ListadoRecetas.this, RecetaEspecifica.class);
                i.putExtra("nombre", r.getNombre());
                i.putExtra("ingredientes", r.getIngredientes());
                i.putExtra("elaboracion", r.getElaboracion());
                i.putExtra("id_imagen", r.getId_imagen());
                i.putExtra("id_receta", r.getId());
                startActivity(i);
            }
        });

        //Eliminar una receta
        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Receta receta = (Receta) parent.getItemAtPosition(position);

                //Alert Dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(ListadoRecetas.this);
                builder.setTitle("¿Seguro que quieres eliminar esta receta?");
                builder.setPositiveButton("Sí", (dialog, which) -> {

                    //Eliminar
                    recetaDAO.eliminarReceta(receta.getId());
                    listaRecetas.remove(receta);
                    adapter.notifyDataSetChanged();
                    Toast.makeText(ListadoRecetas.this, "Receta eliminada", Toast.LENGTH_SHORT).show();
                });
                builder.setNegativeButton("No", null);

                AlertDialog dialog = builder.create();
                dialog.show();

                return true;
            }
        });


        //Buscar las recetas
        buscador.addTextChangedListener(new TextWatcher() {
            @Override
            public void afterTextChanged(Editable s) {
                // Creamos una nueva tarea que se ejecutará en 500ms
                runnable = () -> {
                    adapter.filtrar(s.toString());
                };

                // Lanzamos el retraso
                handler.postDelayed(runnable, 500); // 500 milisegundos de retardo
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Cada vez que el usuario escribe, cancelamos el temporizador anterior
                if (runnable != null) {
                    handler.removeCallbacks(runnable);
                }
            }
        });
    }
}