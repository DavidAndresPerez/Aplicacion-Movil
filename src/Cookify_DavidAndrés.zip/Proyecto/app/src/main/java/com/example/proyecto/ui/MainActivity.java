package com.example.proyecto.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyecto.R;

public class MainActivity extends AppCompatActivity {

    View main;
    //Variable para aplicarle la animacion al texto
    TextView textView, eslogan;
    int idUsuario;
    //Variable para la toolbar para el menu
    Toolbar toolbar;

    //Variables para las preferencias
    String tamanioLetra;
    int tamanioLetraInt;
    boolean negrita;
    boolean modoOscuro;

    LinearLayout menu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Referenciar las variables
        textView = findViewById(R.id.tv_TextoPrincipal);
        eslogan = findViewById(R.id.tv_Eslogan);
        toolbar = findViewById(R.id.toolbar);
        main = findViewById(R.id.main);
        menu = findViewById(R.id.menu);


        //Asignar el menu a la toolbar
        setSupportActionBar(toolbar);

        //Recoger el id del ususario
        idUsuario = getIntent().getIntExtra("ID_USUARIO", -1);

        // Para que no se vea el texto del menu en la toolbar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayShowTitleEnabled(false);
        }

        //Animacion del texto
        Animation a = AnimationUtils.loadAnimation(this, R.anim.animacion_principal);
        textView.startAnimation(a);

        cargarPreferencias();


    }

    //Pasar a la ventana de lista de recetas
    public void listaRecetas(View v){
        Intent i = new Intent(this, ListadoRecetas.class);
        i.putExtra("ID_USUARIO", idUsuario);
        startActivity(i);
    }

    //Pasar a la ventana de crear recetas
    public void crearReceta(View v) {
        Intent i = new Intent(this, CrearReceta.class);
        i.putExtra("ID_USUARIO", idUsuario);
        startActivity(i);

    }


    //Pasar a la ventana de recetas favoritas
    public void recetasFavoritas(View v) {
        Intent i = new Intent(this, RecetasFavoritas.class);
        i.putExtra("ID_USUARIO", idUsuario);
        startActivity(i);
    }

    //Inflar el menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //Opciones del menu
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        //Si es ajustes pasar a la ventana de preferencias
        if(id == R.id.menu_ajustes){
            Intent i = new Intent(this, Preferencias.class);
            startActivity(i);
            return true;

        } else if (id == R.id.menu_contacto) {
            Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
            emailIntent.setData(Uri.parse("mailto:d.andres@fp.safavalladolid.com"));
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Ayuda con Cookify");
            emailIntent.putExtra(Intent.EXTRA_TEXT, "Escribe aquí tu problema");
            startActivity(emailIntent);
            return true;

        } else if (id == R.id.menu_problemasComunes){
            AlertDialog alerta = new AlertDialog.Builder(this).create();
            alerta.setTitle("Problemas comunes");
            alerta.setMessage("1. ¿No se guarda la imagen? Revisa los permisos.\n" +
                    "2. ¿Fallo al buscar? Comprueba mayúsculas.\n" +
                    "3. ¿No ves favoritas? Asegúrate de marcar la estrella.\n" +
                    "4. ¿Como se eliminar una receta? Manten pulsada la receta unos segundos");

            //Boton para cerrarlo
            alerta.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });

            alerta.show();
            return true;

        } else if (id == R.id.menu_acercaDe) {
            AlertDialog alerta = new AlertDialog.Builder(this).create();
            alerta.setTitle("Acerca de Cookify");
            alerta.setMessage("Cookify App v2.0\n\n" +
                    "Desarrollada por: David Andrés \n\n" +
                    "Proyecto: Desarrollo apliación Android\n\n" +
                    "© 2026 Todos los derechos reservados.");

            // Botón para cerrarlo siguiendo tu estilo
            alerta.setButton(AlertDialog.BUTTON_POSITIVE, "Cerrar", new android.content.DialogInterface.OnClickListener() {
                @Override
                public void onClick(android.content.DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });

            alerta.show();
            return true;

        } else {
            return super.onOptionsItemSelected(item);
        }
    }
    public void onRestart(){
        super.onRestart();
        cargarPreferencias();
    }

    //Aplicar las preferencias
    public void cargarPreferencias(){
        SharedPreferences preferencias = PreferenceManager.getDefaultSharedPreferences(MainActivity.this);

        //Recuperar lo seleccionado
        negrita = preferencias.getBoolean("letra_negrita", false);
        modoOscuro = preferencias.getBoolean("modo_oscuro", false);

        //Aplicar las preferencias


        //Estilo de letra
        if (negrita) {
            textView.setTypeface(null, android.graphics.Typeface.BOLD);
        } else {
            textView.setTypeface(null, android.graphics.Typeface.NORMAL);
        }

        //Modo oscuro
        if(modoOscuro){
            main.setBackgroundColor(Color.parseColor("#212121"));
            toolbar.setBackgroundColor(Color.parseColor("#212121"));
            textView.setTextColor(Color.WHITE);
            menu.setBackgroundColor(Color.parseColor("#8B5E3C"));
        } else {
            main.setBackgroundColor(Color.parseColor("#FAE5C5")); //Color de fondo de la aplicacion
            textView.setTextColor(Color.BLACK);
            toolbar.setBackgroundColor(Color.parseColor("#FAE5C5"));
            menu.setBackgroundColor(Color.parseColor("#8B5E3C"));
        }
    }
}
