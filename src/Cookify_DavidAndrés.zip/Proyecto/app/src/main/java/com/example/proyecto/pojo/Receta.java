package com.example.proyecto.pojo;

public class Receta {

    //Atributos
    private int id;
    private String nombre;
    private String ingredientes;
    private String elaboracion;
    private int id_imagen;
    private boolean favorita;
    private int usuario_id;


    //Constructor vacio
    public Receta() {
    }

    //Constructor
    public Receta(int id, String nombre, String ingredientes, String elaboracion, int id_imagen, boolean favorita, int usuario_id) {
        this.id = id;
        this.nombre = nombre;
        this.ingredientes = ingredientes;
        this.elaboracion = elaboracion;
        this.id_imagen = id_imagen;
        this.favorita = favorita;
        this.usuario_id = usuario_id;
    }

    //Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public String getElaboracion() {
        return elaboracion;
    }

    public void setElaboracion(String elaboracion) {
        this.elaboracion = elaboracion;
    }

    public int getId_imagen() {
        return id_imagen;
    }

    public void setId_imagen(int id_imagen) {
        this.id_imagen = id_imagen;
    }

    public boolean isFavorita() {
        return favorita;
    }

    public void setFavorita(boolean favorita) {
        this.favorita = favorita;
    }

    public int getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(int usuario_id) {
        this.usuario_id = usuario_id;
    }
}
