package com.example.proyecto.adapter;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.proyecto.dao.ImagenDAO;
import com.example.proyecto.R;
import com.example.proyecto.pojo.Receta;
import com.example.proyecto.dao.RecetaDAO;

import java.util.ArrayList;

public class Adaptador_Receta extends BaseAdapter {

    Context context;

    ArrayList<Receta> recetas;
    ArrayList<Receta> listaRecetas;
    ImagenDAO imagenDAO;
    int usuario_id;

    //Constructor
    public Adaptador_Receta(Context context, ArrayList<Receta> recetas, ImagenDAO imagenDAO,int usuario_id) {
        this.context = context;
        this.recetas = recetas;
        this.imagenDAO = imagenDAO;
        this.usuario_id = usuario_id;

        this.listaRecetas = new ArrayList<>(recetas);
    }

    //Metodo para hacer el filtrado de la ventana de lista de recetas
    public void filtrar(String texto) {
        recetas.clear();

        if (texto == null || texto.isEmpty()) {
            recetas.addAll(listaRecetas);
        } else {
            String textoMinusculas = texto.toLowerCase();

            for (Receta receta : listaRecetas) {
                if (receta.getNombre().toLowerCase().contains(textoMinusculas)) {
                    recetas.add(receta);
                }

            }
        }
        notifyDataSetChanged();
    }


    @Override
    public int getCount() {
        return recetas.size();
    }

    @Override
    public Object getItem(int position) {
        return recetas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return recetas.get(position).getId();
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View vista = convertView;
        if (vista == null) {
            vista = View.inflate(context, R.layout.estilo_tarjetas, null);
        }

        Receta receta = recetas.get(position);

        ImageView img = vista.findViewById(R.id.img_receta);
        TextView nombre = vista.findViewById(R.id.tv_nombreReceta);
        ImageButton btn = vista.findViewById(R.id.btn_favorito);

        nombre.setText(receta.getNombre());

        //Recuperar y tratar la imagen
        byte[] imagenBytes = imagenDAO.obtenerImagen(receta.getId_imagen());
        if(imagenBytes != null){
            Bitmap bitmap = android.graphics.BitmapFactory.decodeByteArray(imagenBytes, 0, imagenBytes.length);
            img.setImageBitmap(bitmap);
        } else {
            img.setImageResource(R.drawable.imagendefecto2);
        }

        //Icono en funcion de si es favorita
        if (receta.isFavorita()) {
            btn.setImageResource(R.drawable.estrella2);
        } else {
            btn.setImageResource(R.drawable.estrella);
        }

        // Si se pulsa la estrella se cambia el estado
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (receta.isFavorita()) {
                    receta.setFavorita(false);
                    btn.setImageResource(R.drawable.estrella);
                } else {
                    receta.setFavorita(true);
                    btn.setImageResource(R.drawable.estrella2);
                }

                //Guardar el cambio en la base de datos
                RecetaDAO dao = new RecetaDAO(context);
                dao.cambiarEstadoReceta(receta.getId(), receta.isFavorita(), usuario_id);
            }
        });

        return vista;
    }

}
