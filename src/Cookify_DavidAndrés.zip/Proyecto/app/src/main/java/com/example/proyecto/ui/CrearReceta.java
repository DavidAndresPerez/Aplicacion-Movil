
package com.example.proyecto.ui;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyecto.R;
import com.example.proyecto.dao.ImagenDAO;
import com.example.proyecto.dao.RecetaDAO;
import com.example.proyecto.pojo.Receta;

public class CrearReceta extends AppCompatActivity {

    //Variables
    EditText nombre;
    ImageView fotoReceta;
    private static final int PICK_IMAGE = 100;  //Para identificar la seleccion de la foto
    private Uri selectedImageUri = null; //Para guardar la URI de la imagen seleccionada
    LinearLayout layoutIngredientes;
    ListView listaIngredientes;
    Button botonAniadirIngrediente;
    Button botonCrearReceta;
    EditText elaboracion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_crear_receta);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Referenciar las variables
        nombre = findViewById(R.id.etv_nombreReceta);
        fotoReceta = findViewById(R.id.imagen_Receta);
        layoutIngredientes = findViewById(R.id.lv_Ingredientes);
        botonAniadirIngrediente = findViewById(R.id.btn_aniadirIngrediente);
        elaboracion = findViewById(R.id.etv_elaboracion);
        botonCrearReceta = findViewById(R.id.btn_aniadirReceta);


        //Al pulsar en el icono de la foto abre los archivos
        fotoReceta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");      //Para que el tipo de archivo sea una imagen
                startActivityForResult(Intent.createChooser(intent, "Selecciona una imagen"), PICK_IMAGE);
            }
        });

        //Al pulsar el boton de añadir recetas salen tarjetas para añadir los igredientes
        botonAniadirIngrediente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Comprobar que la tarjeta anterior no esta vacia
                if (layoutIngredientes.getChildCount() > 0) {
                    View ultimaTarjeta = layoutIngredientes.getChildAt(layoutIngredientes.getChildCount() - 1);
                    EditText ultimoIngrediente = ultimaTarjeta.findViewById(R.id.etIngrediente);

                    if (ultimoIngrediente.getText().toString().trim().isEmpty()) {
                        Toast.makeText(CrearReceta.this, "Rellena el ingrediente anterior", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
                //Inflar el layout de la tarjeta de ingredientes
                LinearLayout tarjetaIngrediente = (LinearLayout) getLayoutInflater()
                        .inflate(R.layout.aniadir_ingrediente, layoutIngredientes, false);

                //Cojer las referencias del texto y el boton del layout de añadir ingrediente
                EditText ingrediente = tarjetaIngrediente.findViewById(R.id.etIngrediente);
                Button guardarIngrediente = tarjetaIngrediente.findViewById(R.id.btnGuardarIngrediente);

                //Cuando se pulsa en gardar se quita el boton y no se puede editar mas el texto del ingrediente
                guardarIngrediente.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (ingrediente.isEnabled()) {
                            // Si está editable bloquearlo
                            if (!ingrediente.getText().toString().trim().isEmpty()) {
                                ingrediente.setEnabled(false);
                                guardarIngrediente.setText("Borrar"); // Cambiamos el texto del botón
                                guardarIngrediente.setBackgroundColor(Color.RED);
                            } else {
                                Toast.makeText(CrearReceta.this, "No puedes guardar un ingrediente vacío", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            // Si ya estaba bloqueado y pulsa "Borrar", quitamos la tarjeta
                            layoutIngredientes.removeView(tarjetaIngrediente);
                        }
                    }
                });

                //Añadir la tarjeta al layout de ingredientes
                layoutIngredientes.addView(tarjetaIngrediente);
            }
        });

        //Evento para guardar la receta
        botonCrearReceta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                guardarReceta(v);
            }
        });

    }

    //Cuando ha seleccionado la imagen se muestra en el cuadro de la imagen del layout
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            // Obtener la URI de la imagen seleccionada
            fotoReceta.setImageURI(data.getData()); // Mostrar la imagen en el ImageView
            selectedImageUri = data.getData();
        }
    }

    //Metodo para guardar la receta
    public void guardarReceta(View view) {

        //Recoger lo valores
        String nombreReceta = nombre.getText().toString().trim();
        String ingredientes = "";
        String elaboracionReceta = elaboracion.getText().toString().trim();

        //Recoger todos los ingredientes de la receta

        //Recorrer todas las tarjetas de los ingredientes
        for(int i = 0; i < layoutIngredientes.getChildCount(); i++){

            //Obtener la tarjeta de cada posición
            LinearLayout tarjetaIngrediente = (LinearLayout) layoutIngredientes.getChildAt(i);

            //Obtener el texto del ingrediente
            EditText ingrediente = tarjetaIngrediente.findViewById(R.id.etIngrediente);

            //Añadirlo a la variable
            String ingredienteActual = ingrediente.getText().toString().trim();

            if(!ingredienteActual.isEmpty()){
                ingredientes += ingredienteActual + "\n";
            }
        }

        //Validaciones
        if (nombreReceta.isEmpty() || elaboracionReceta.isEmpty() || ingredientes.isEmpty()) {
           Toast.makeText(this, "Rellena todos los campos de texto", Toast.LENGTH_SHORT).show();
        } else {

            RecetaDAO recetaDAO = new RecetaDAO(this);

            //Obtenemos el ID del usuario que viene del Intent
            int idUsuario = getIntent().getIntExtra("ID_USUARIO", -1);

            if (recetaDAO.buscarReceta(nombreReceta,idUsuario)) {
                Toast.makeText(this, "La receta ya existe", Toast.LENGTH_SHORT).show();
            } else {
                byte[] fotoBytes;
                Bitmap bitmap = null;

                //Comprobar si hay imagen si no settear la imagen por defecto
                try {
                    //Si ha seleccionado una imagen
                    if (selectedImageUri != null) {
                        bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), selectedImageUri);
                    } else {
                        //Si no ha seleccionado una imagen
                        bitmap = android.graphics.BitmapFactory.decodeResource(getResources(), R.drawable.imagendefecto2);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

                //Conexion y DAOS
                if (bitmap != null) {
                    ImagenDAO imagenDAO = new ImagenDAO(this);

                    //Insertar la imagen
                    long idImagen = imagenDAO.insertarImagen(bitmap);

                    if (idImagen != -1) {
                        //Insertar la receta
                        Receta receta = new Receta();
                        receta.setNombre(nombreReceta);
                        receta.setIngredientes(ingredientes);
                        receta.setElaboracion(elaboracionReceta);
                        receta.setFavorita(false);

                        //ID de la imagen que hemos guardado
                        receta.setId_imagen((int) idImagen);
                        receta.setUsuario_id(idUsuario);

                        //Insertar la receta
                        long idReceta = recetaDAO.insertarReceta(receta);

                        if (idReceta != -1) {
                            Toast.makeText(this, "Receta guardada", Toast.LENGTH_SHORT).show();
                            finish(); //Ir a la pantalla principal
                        } else {
                            Toast.makeText(this, "Error al guardar la receta", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(this, "Error al guardar la imagen", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(this, "Error al procesar la imagen", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}