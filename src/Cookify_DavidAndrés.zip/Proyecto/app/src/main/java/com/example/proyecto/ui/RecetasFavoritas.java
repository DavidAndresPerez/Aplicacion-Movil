package com.example.proyecto.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyecto.R;
import com.example.proyecto.adapter.Adaptador_Receta;
import com.example.proyecto.dao.ImagenDAO;
import com.example.proyecto.dao.RecetaDAO;
import com.example.proyecto.pojo.Receta;

import java.util.ArrayList;

public class RecetasFavoritas extends AppCompatActivity {

    //Variables
    ListView lista;
    RecetaDAO recetaDAO;
    ImagenDAO imagenDAO;
    ArrayList<Receta> listaFavoritas;
    Adaptador_Receta adapter;
    int idUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_recetas_favoritas);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Referenciar las variables
        lista = findViewById(R.id.lv_recetas);


        //Inicializar los daos
        recetaDAO = new RecetaDAO(this);
        imagenDAO = new ImagenDAO(this);

        //ID del usuario
        idUsuario = getIntent().getIntExtra("ID_USUARIO", -1);

        //Recoger las recetas favoritas de este usuario de la base de datos
        listaFavoritas = (ArrayList<Receta>) recetaDAO.obtenerRecetasFavoritas(idUsuario);

        //Pasarselas con un adaptador al listview
        adapter = new Adaptador_Receta(this, listaFavoritas, imagenDAO, idUsuario);
        lista.setAdapter(adapter);

        //Al pulsar sobre una receta ver sus detalles
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Obtenemos la receta de la posición pulsada
                Receta r = (Receta) adapter.getItem(position);

                // Creamos el Intent para ir a los detalles
                Intent i = new Intent(RecetasFavoritas.this, RecetaEspecifica.class);
                i.putExtra("nombre", r.getNombre());
                i.putExtra("ingredientes", r.getIngredientes());
                i.putExtra("elaboracion", r.getElaboracion());
                i.putExtra("id_imagen", r.getId_imagen());
                i.putExtra("id_receta", r.getId());

                startActivity(i);
            }
        });
    }

    //Metodo onResume para que se recarge la lista al volver a la pantalla
    @Override
    protected void onResume() {
        super.onResume();
        cargarDatos();
    }

    //Metodo para cargar los datos
    private void cargarDatos() {

        ArrayList<Receta> actualizada = (ArrayList<Receta>) recetaDAO.obtenerRecetasFavoritas(idUsuario);

        //Limpiar la lista
        listaFavoritas.clear();

        //Añadir las recetas favoritas
        listaFavoritas.addAll(actualizada);

        //Actualizar el adaptador
        adapter.notifyDataSetChanged();
    }
}