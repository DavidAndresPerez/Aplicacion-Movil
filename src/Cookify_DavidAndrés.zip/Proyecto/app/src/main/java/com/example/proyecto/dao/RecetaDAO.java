package com.example.proyecto.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.proyecto.conexion.ConexionSQLite;
import com.example.proyecto.pojo.Receta;

import java.util.ArrayList;
import java.util.List;

public class RecetaDAO {

    //Variables
    private SQLiteDatabase dbHelper;

    //Constructor
    public RecetaDAO(Context context) {
        dbHelper = new ConexionSQLite(context).getWritableDatabase();
    }

    public RecetaDAO(SQLiteDatabase dbHelper) {
        this.dbHelper = dbHelper;
    }

    //Metodo para inserta una receta
    public long insertarReceta(Receta receta) {
        ContentValues values = new ContentValues();
        values.put("nombre", receta.getNombre());
        values.put("ingredientes", receta.getIngredientes());
        values.put("elaboracion", receta.getElaboracion());
        values.put("favorita", receta.isFavorita() ? 1 : 0);
        values.put("usuario_id", receta.getUsuario_id());
        values.put("id_imagen", receta.getId_imagen());

        return dbHelper.insert("RECETAS", null, values);
    }

    //Metodo para obtener las recetas de un usuario
    public List<Receta> obtenerRecetas(int usuario_id) {
        List<Receta> recetas = new ArrayList<>();

        //Consulta
        String query = "SELECT * FROM RECETAS WHERE usuario_id = ?";

        //Cursor
        Cursor cursor = dbHelper.rawQuery(query, new String[]{String.valueOf(usuario_id)});

        //Añadir las recetas a la lista
        if (cursor.moveToFirst()) {
            do {
                Receta receta = new Receta();
                receta.setId(cursor.getInt(0));
                receta.setNombre(cursor.getString(1));
                receta.setIngredientes(cursor.getString(2));
                receta.setElaboracion(cursor.getString(3));
                receta.setFavorita(cursor.getInt(4) == 1);
                receta.setUsuario_id(cursor.getInt(5));
                receta.setId_imagen(cursor.getInt(6));
                recetas.add(receta);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return recetas;

    }

    //Metodo para obtener las recetas favoritas de un usuario
    public List<Receta> obtenerRecetasFavoritas(int usuario_id) {
        List<Receta> recetas = new ArrayList<>();

        //Consulta
        String query = "SELECT * FROM RECETAS WHERE usuario_id = ? AND favorita = 1";

        //Cursor
        Cursor cursor = dbHelper.rawQuery(query, new String[]{String.valueOf(usuario_id)});

        if (cursor.moveToFirst()) {
            do {
                Receta receta = new Receta();
                receta.setId(cursor.getInt(0));
                receta.setNombre(cursor.getString(1));
                receta.setIngredientes(cursor.getString(2));
                receta.setElaboracion(cursor.getString(3));
                receta.setFavorita(cursor.getInt(4) == 1);
                receta.setUsuario_id(cursor.getInt(5));
                receta.setId_imagen(cursor.getInt(6));
                recetas.add(receta);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return recetas;
    }


    //Metodo para cambiar el estado de una receta (añadirla o quitarla de favoritas)
    public void cambiarEstadoReceta(int id, boolean favorita, int usuario_id) {

        ContentValues values = new ContentValues();

        if (favorita) {
            values.put("favorita", 1);
        } else {
            values.put("favorita", 0);
        }

        //Actualizar la receta con ese ID
        dbHelper.update("RECETAS", values, "id = ? AND usuario_id = ?",
                new String[]{String.valueOf(id), String.valueOf(usuario_id)});
    }

    //Metodo para buscar una receta por su nombre
    public boolean buscarReceta(String nombre, int usuario_id) {

        boolean encontrado = false;

        //Consulta
        String query = "SELECT * FROM RECETAS WHERE nombre = ? and usuario_id = ?";

        //Cursor
        Cursor cursor = dbHelper.rawQuery(query, new String[]{nombre, String.valueOf(usuario_id)});

        //Si encuentra una receta
        if (cursor.moveToFirst()) {
            encontrado = true;
        }

        cursor.close();

        return encontrado;
    }

    //Metodo para eliminar una receta
    public void eliminarReceta(int id) {
        dbHelper.delete("RECETAS", "id = ?", new String[]{String.valueOf(id)});

    }
}