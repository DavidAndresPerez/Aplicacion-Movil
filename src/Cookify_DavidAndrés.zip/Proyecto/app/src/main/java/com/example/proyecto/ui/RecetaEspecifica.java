package com.example.proyecto.ui;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyecto.R;
import com.example.proyecto.dao.ImagenDAO;

public class RecetaEspecifica extends AppCompatActivity {

    //Variables
    TextView nombre, ingredientes,  elaboracion;
    ImageView fotoReceta;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_receta_especifica);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Referencias las variables
        nombre = findViewById(R.id.tv_nombre);
        ingredientes = findViewById(R.id.tv_ingredientes);
        elaboracion = findViewById(R.id.tv_elaboracion);
        fotoReceta = findViewById(R.id.img_recetaSeleccionada);

        //Recuperar los valores pasados en el intent
        String nombreReceta = getIntent().getStringExtra("nombre");
        String elaboracionReceta = getIntent().getStringExtra("elaboracion");
        String ingredientesReceta = getIntent().getStringExtra("ingredientes");
        int idImagen = getIntent().getIntExtra("id_imagen", -1);

        //Asignar los valores a las variables
        nombre.setText(nombreReceta);
        ingredientes.setText(ingredientesReceta);
        elaboracion.setText(elaboracionReceta);

        //Cargar la foto desde la base de datos
        if(idImagen != -1){
            ImagenDAO imagenDAO = new ImagenDAO(this);
            byte[] imagenBytes = imagenDAO.obtenerImagen(idImagen);
            if(imagenBytes != null){
                Bitmap bitmap = BitmapFactory.decodeByteArray(imagenBytes, 0, imagenBytes.length);
                fotoReceta.setImageBitmap(bitmap);
            }
        }

    }
}