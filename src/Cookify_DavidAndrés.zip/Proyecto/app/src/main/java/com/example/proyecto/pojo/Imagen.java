package com.example.proyecto.pojo;

public class Imagen {


    //Atributos
    private int id;
    private byte[] imagen;

    //Constructor vacio
    public Imagen() {
    }

    //Constructor sin id
    public Imagen(byte[] imagen) {
        this.imagen = imagen;
    }

    //Constructor con id
    public Imagen(int id, byte[] imagen) {
        this.id = id;
        this.imagen = imagen;
    }

    //Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }
}
