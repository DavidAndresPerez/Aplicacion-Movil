package com.example.proyecto.ui;

import android.os.Bundle;
import android.preference.PreferenceActivity;

import com.example.proyecto.R;

public class Preferencias extends PreferenceActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.ventana_preferencias);
    }


}
