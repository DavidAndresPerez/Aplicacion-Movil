package com.example.proyecto.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;

import com.example.proyecto.conexion.ConexionSQLite;

import java.io.ByteArrayOutputStream;

public class ImagenDAO {

    private SQLiteDatabase dbHelper;

    //Constructor
    public ImagenDAO(Context context) {
        dbHelper = new ConexionSQLite(context).getWritableDatabase();
    }


    //Metodo para insertar una imagen
    public long insertarImagen(Bitmap imagen) {
        if (imagen != null) {
            ContentValues values = new ContentValues();

            // Redimensionar el bitmap si es muy grande para evitar errores
            Bitmap imagenReducida = Bitmap.createScaledBitmap(imagen, 500, 500, true);

            // Convertir a JPEG que pesa menos que PNG
            ByteArrayOutputStream stream = new ByteArrayOutputStream();

            // Bajamos la calidad al 50%. Para una miniatura en una app es suficiente.
            imagenReducida.compress(Bitmap.CompressFormat.JPEG, 50, stream);
            byte[] imagenBytes = stream.toByteArray();

            values.put("imagen", imagenBytes);

            return dbHelper.insert("IMAGENES", null, values);
        } else {
            return -1;
        }
    }

    //Metodo para recuperar las imagenes guardadas en la base de datos por su id
    public byte[] obtenerImagen(int id) {

        byte[] imagenBytes = null;

        //Consulta
        String query = "SELECT imagen FROM IMAGENES WHERE id = ?";

        //Cursor
        Cursor cursor = dbHelper.rawQuery(query, new String[]{String.valueOf(id)});

        if (cursor.moveToFirst()) {
            imagenBytes = cursor.getBlob(0);
            cursor.close();
        }

        return imagenBytes;

    }
}
